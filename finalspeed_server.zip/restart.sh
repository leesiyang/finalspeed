#!/bin/sh
cd /fs/
sh stop.sh
sh start.sh

